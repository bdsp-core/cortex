import { logNdtr, logSumExp, logSumExp2, normCdf } from "./math";
import { groupForTask } from "./profile";
import type {
  ConditionalF1Artifact, EngineProfile, Observation, ProtocolSegment, ResponseGroup,
} from "./types";

export const BINARY_LAPSE = 0.025;
const LOG_LAPSE = Math.log(BINARY_LAPSE);
const LOG_ONE_MINUS_TWO_LAPSE = Math.log1p(-2 * BINARY_LAPSE);

export function signalZ(l: number, t: number, s: number, sSd = 0): number {
  const sensitivity = Math.exp(l);
  let z = sensitivity * (s + t);
  if (sSd !== 0) z /= Math.sqrt(1 + (sensitivity * sSd) ** 2);
  return z;
}

export function binaryPYes(z: number): number {
  return BINARY_LAPSE + (1 - 2 * BINARY_LAPSE) * normCdf(z);
}

export function logPBinary(z: number, y: 0 | 1): number {
  const cdf = LOG_ONE_MINUS_TWO_LAPSE + logNdtr(y === 1 ? z : -z);
  return logSumExp2(cdf, LOG_LAPSE);
}

export function makeObservation(
  profile: EngineProfile,
  askedK: number,
  segmentIndex: number,
  rawPick: number,
): Observation {
  const group = groupForTask(profile, askedK);
  if (group.link === "binary") {
    return {
      kind: "binary", askedK, segmentIndex, rawPick,
      y: rawPick === askedK ? 1 : 0,
    };
  }
  if (!group.taskIndices.includes(rawPick)) {
    throw new Error(`categorical pick ${rawPick} is outside response group ${group.id}`);
  }
  return {
    kind: "categorical_f1", groupId: group.id, askedK, segmentIndex,
    rawPick, pickK: rawPick,
  };
}

function zFor(
  taskK: number,
  segment: ProtocolSegment,
  t: Float64Array,
  l: Float64Array,
  particleOffset: number,
): number {
  return signalZ(
    l[particleOffset + taskK], t[particleOffset + taskK],
    segment.sMean[taskK], segment.sSd[taskK],
  );
}

function logDistractorProbability(
  group: ResponseGroup,
  askedK: number,
  pickK: number,
  segment: ProtocolSegment,
  t: Float64Array,
  l: Float64Array,
  particleOffset: number,
  artifact: ConditionalF1Artifact,
): number {
  const distractors = group.taskIndices.filter((taskK) => taskK !== askedK);
  const logits = distractors.map(
    (taskK) => artifact.beta * zFor(taskK, segment, t, l, particleOffset),
  );
  const pickIndex = distractors.indexOf(pickK);
  if (pickIndex < 0) throw new Error("pick is not a valid distractor");
  const logSoftmax = logits[pickIndex] - logSumExp(logits);
  const uniform = artifact.distractorLapse === 0
    ? -Infinity
    : Math.log(artifact.distractorLapse) - Math.log(distractors.length);
  const directed = artifact.distractorLapse === 1
    ? -Infinity
    : Math.log1p(-artifact.distractorLapse) + logSoftmax;
  return logSumExp2(uniform, directed);
}

export function logProbability(
  profile: EngineProfile,
  artifact: ConditionalF1Artifact | undefined,
  observation: Observation,
  segment: ProtocolSegment,
  t: Float64Array,
  l: Float64Array,
  particleIndex: number,
  taskCount: number,
): number {
  if (segment.segmentIndex !== observation.segmentIndex) {
    throw new Error("observation/segment index mismatch");
  }
  const offset = particleIndex * taskCount;
  const ownZ = zFor(observation.askedK, segment, t, l, offset);
  if (observation.kind === "binary") return logPBinary(ownZ, observation.y);
  if (!artifact) throw new Error("categorical observation requires an F1 artifact");
  const group = groupForTask(profile, observation.askedK);
  if (group.id !== observation.groupId || group.link !== "categorical_f1") {
    throw new Error("observation response group mismatch");
  }
  if (observation.pickK === observation.askedK) return logPBinary(ownZ, 1);
  return logPBinary(ownZ, 0) + logDistractorProbability(
    group, observation.askedK, observation.pickK,
    segment, t, l, offset, artifact,
  );
}

export function responseProbabilities(
  profile: EngineProfile,
  artifact: ConditionalF1Artifact | undefined,
  askedK: number,
  segment: ProtocolSegment,
  t: Float64Array,
  l: Float64Array,
  particleIndex: number,
  taskCount: number,
): { outcome: number; probability: number }[] {
  const group = groupForTask(profile, askedK);
  if (group.link === "binary") {
    const offset = particleIndex * taskCount;
    const yes = binaryPYes(zFor(askedK, segment, t, l, offset));
    return [{ outcome: askedK, probability: yes }, { outcome: taskCount, probability: 1 - yes }];
  }
  if (!artifact) throw new Error("categorical response group requires an F1 artifact");
  // The selector calls this N × candidates times. Compute the distractor
  // softmax once per particle/candidate rather than rebuilding it separately
  // for each of the six possible outcomes.
  const offset = particleIndex * taskCount;
  const own = binaryPYes(zFor(askedK, segment, t, l, offset));
  const distractors = group.taskIndices.filter((taskK) => taskK !== askedK);
  const logits = distractors.map(
    (taskK) => artifact.beta * zFor(taskK, segment, t, l, offset),
  );
  const maximum = Math.max(...logits);
  const exponentials = logits.map((logit) => Math.exp(logit - maximum));
  const denominator = exponentials.reduce((sum, value) => sum + value, 0);
  return group.taskIndices.map((outcome) => {
    if (outcome === askedK) return { outcome, probability: own };
    const distractorIndex = distractors.indexOf(outcome);
    const directed = exponentials[distractorIndex] / denominator;
    const q = artifact.distractorLapse / distractors.length
      + (1 - artifact.distractorLapse) * directed;
    return { outcome, probability: (1 - own) * q };
  });
}
