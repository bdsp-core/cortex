from __future__ import annotations

import hashlib
import json
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parent


def test_exploratory_artifact_is_schema_valid_hash_bound_and_nonpromotable():
    artifact = json.loads((ROOT / "artifacts/iiic_conditional_f1_stage2_exploratory.json").read_text())
    schema = json.loads((ROOT / "schemas/response-artifact.schema.json").read_text())
    jsonschema.validate(artifact, schema)
    source = REPO / artifact["provenance"]["source"]
    assert hashlib.sha256(source.read_bytes()).hexdigest() == artifact["sha256"]
    assert artifact["qualification"] == "exploratory_unqualified"
    assert artifact["provenance"]["dr07"] == "not_qualified"
    assert artifact["promotionForbidden"] is True


def test_migration_is_additive_and_preserves_raw_pick_column():
    migration = (ROOT / "server/migration.sql").read_text().lower()
    assert "alter table sessions add column" in migration
    assert "drop table" not in migration
    assert "delete from" not in migration
    assert "trials" in migration and "pick" in migration

