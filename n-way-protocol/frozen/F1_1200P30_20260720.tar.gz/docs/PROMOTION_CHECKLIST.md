# Production promotion checklist

No item in this file authorizes a production change. Promotion requires a
separate explicit green light after every mandatory item is evidenced.

- [ ] DR07 scientific prerequisite passes on a new versioned fit.
- [ ] Response artifact is leakage-controlled, held-out calibrated, hashed,
      reviewed, and marked `qualified`.
- [ ] TypeScript/Python fixed-cloud and adaptive trajectory parity passes.
- [ ] Binary production golden suite remains unchanged.
- [ ] Skill SBC/recovery, RMSE, coverage, and width gates pass.
- [ ] Bias SBC/recovery, RMSE, coverage, and width gates pass.
- [ ] Full adaptive operating-characteristic decision gates pass.
- [ ] Selector-regret and production-bank latency gates pass.
- [ ] Particle/ESS/MH/MCSE profile is requalified and frozen.
- [ ] Serial and ranked-worker branches produce the same adopted state.
- [ ] Old binary sessions resume and finish byte-identically.
- [ ] N-way sessions reject profile/artifact drift on resume and result ingest.
- [ ] `isCorrect` is gold-derived; `matchedAskedTask` is a separate diagnostic.
- [ ] Server-owned rollout is off by default and unknown values fail closed.
- [ ] Offline shadow and internal test phases have reviewed reports.
- [ ] Allowlisted serial and ranked-worker phases meet observation gates.
- [ ] Rollback changes only new-session assignment and never changes an
      in-progress sitting's response model.
- [ ] Production code change is reviewed as a deliberate promotion from this
      directory, not copied ad hoc.

