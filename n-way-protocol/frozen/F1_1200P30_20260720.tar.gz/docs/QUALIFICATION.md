# Qualification contract

The included harness is executable adaptive-selection/frontier infrastructure,
not a completed scientific qualification. Its current stopping point is the
configured direct-domain cap; it deliberately does not claim to reproduce the
locked Precision stopping rule. The TypeScript `precision_bridge.ts` exercises
that unchanged policy boundary. A promotion run must join the two in the
governed harness, be preregistered, and use a newly qualified response artifact.

## Prerequisites

- A versioned DR07 refit with at least 32 exact same-state joint draws plus
  state zero, followed by the governed rank/conditioning gate.
- Leakage-controlled distractor fitting: held-out readers and patient/source
  groups; the participant's response must not contribute to its item axis.
- Frozen `beta`, distractor lapse, prior/correlation artifacts, source hashes,
  seeds, populations, and analysis code.
- Owner-approved noninferiority margins set before the locked run.

## Required run families

1. Likelihood and parameter-recovery SBC over low, medium, and high skill and
   bias, correlated/heterogeneous profiles, and signal uncertainty.
2. Misspecification stress: lapse drift, distractor-scale drift, correlated
   criteria, source shift, and noisy/miscalibrated evidence axes.
3. Full adaptive comparison on the served bank using each arm's own selector
   and the unchanged Precision stopping policy.
4. Fixed-sequence historical shadow replay for real-response model checking.
   This does not qualify adaptive selection.
5. Browser/device performance and exact serial-versus-speculative parity.

## Promotion metrics

- Skill and bias posterior mean bias and RMSE.
- 95% interval coverage and width for both parameter blocks.
- The existing categorical coverage guardrail versus binary, plus an absolute
  nominal-coverage gate with Monte Carlo confidence intervals.
- False pass, false fail, refer, cap, and bank-exhaustion rates.
- Median, p90, and p95 total and per-domain burden.
- ESS, resampling frequency, MH acceptance, ancestry, and MCSE reliability.
- Selector regret versus exhaustive evaluation on tractable banks.
- p50/p95/max answer-to-item latency, memory, worker failure, and fallback.

The 1,200-particle, ESS 0.5, 30-MH, and MCSE-inflation values must be
requalified. They are not inherited merely because the stopping rule is
unchanged.

The default planted-population harness uses a shifted/narrower truth
distribution as a prior-mismatch stress test, so its rank histograms are not
formal SBC. Pass `--formal-sbc` to draw planted parameters from the inference
prior and make the rank-uniformity interpretation valid.

## Resource policy

The parallel harness reserves two logical CPUs and 20% of available memory.
Each process owns one BLAS thread. On the current 48-thread host the CPU ceiling
is therefore 46 worker processes, further limited by replicate count and the
memory estimate.
